import React, { useState, useEffect } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import LocationDropdown from "../Components/LocationDropdown";

// ***************************************************************
// 🚀 CATEGORY FIELD CONFIGURATION (All 14 Categories)
// ***************************************************************

const CATEGORY_FIELDS = {
    // 📱 1. MOBILE CATEGORY FIELDS
    "Mobile": [
        { name: "brand", placeholder: "Brand (e.g., Samsung)", type: "text", required: true },
        { name: "model", placeholder: "Model (e.g., S21 Ultra)", type: "text", required: true },
        { name: "storage", placeholder: "Storage (e.g., 128GB)", type: "text", required: true },
        { name: "ram", placeholder: "RAM (e.g., 8GB)", type: "text", required: true },
        { name: "batteryHealth", placeholder: "Battery Health %", type: "number", required: true },
        { name: "ptaStatus", placeholder: "PTA Status", type: "select", options: ["Approved", "Non-Approved", "Blocked"], required: true },
        { name: "warranty", placeholder: "Warranty", type: "select", options: ["Avalible", "Not Avalible"], required: true },
        { name: "warrantyDuration", placeholder: "Warranty Duration (if Avalible)", type: "text", optional: true, dependsOn: { field: "warranty", value: "Avalible" } },
        { name: "accessories", placeholder: "Accessories (e.g., Box, Charger)", type: "text" },
    ],
    // 🚗 2. VEHICLES (CAR) CATEGORY FIELDS
    "Car": [
        { name: "make", placeholder: "Make (e.g., Honda, Toyota)", type: "text", required: true },
        { name: "carModel", placeholder: "Model (e.g., Civic, Corolla)", type: "text", required: true },
        { name: "year", placeholder: "Manufacturing Year", type: "number", required: true },
        { name: "mileage", placeholder: "Mileage (in KM)", type: "number", required: true },
        { name: "fuelType", placeholder: "Fuel Type", type: "select", options: ["Petrol", "Diesel", "Hybrid"], required: true },
        { name: "transmission", placeholder: "Transmission", type: "select", options: ["Automatic", "Manual"], required: true },
        { name: "registrationCity", placeholder: "Registration City", type: "text", required: true },
    ],
    // 🏠 3. FURNITURE
    "Furniture": [
        { name: "material", placeholder: "Material (Wood, Plastic)", type: "text", required: true },
        { name: "dimensions", placeholder: "Dimensions (e.g., 6ft x 3ft)", type: "text", required: true },
        { name: "age", placeholder: "Age (in years)", type: "number" },
    ],
    // 🏘️ 4. PROPERTY FOR SALE
    "PropertySale": [
        { name: "propertyType", placeholder: "Type (House, Plot, Flat)", type: "select", options: ["House", "Plot", "Flat", "Farm House"], required: true },
        { name: "areaSize", placeholder: "Area Size (e.g., 5 Marla)", type: "text", required: true },
        { name: "unit", placeholder: "Area Unit", type: "select", options: ["Marla", "Kanal", "Sq. Ft."], required: true },
        { name: "bedrooms", placeholder: "Number of Bedrooms", type: "number" },
        { name: "bathrooms", placeholder: "Number of Bathrooms", type: "number" },
        { name: "possession", placeholder: "Possession Status", type: "select", options: ["Yes", "No"], required: true },
    ],
    // 🏡 5. PROPERTY FOR RENT
    "PropertyRent": [
        { name: "propertyType", placeholder: "Type (House, Flat, Room)", type: "select", options: ["House", "Flat", "Room", "Office"], required: true },
        { name: "areaSize", placeholder: "Area Size (e.g., 10 Marla)", type: "text", required: true },
        { name: "unit", placeholder: "Area Unit", type: "select", options: ["Marla", "Kanal", "Sq. Ft."], required: true },
        { name: "rentDuration", placeholder: "Rent Duration (Monthly/Yearly)", type: "select", options: ["Monthly", "Yearly"], required: true },
        { name: "deposit", placeholder: "Security Deposit Amount", type: "number" },
    ],
    // 📺 6. ELECTRONICS & HOME APPLIANCES
    "Electronics": [
        { name: "itemType", placeholder: "Item Type (TV, AC, Fridge)", type: "text", required: true },
        { name: "make", placeholder: "Make/Brand", type: "text", required: true },
        { name: "model", placeholder: "Model Name", type: "text" },
        { name: "age", placeholder: "Age (in months/years)", type: "text" },
        { name: "warrantyStatus", placeholder: "Warranty Status", type: "select", options: ["In Warranty", "Expired", "Not Applicable"], required: true },
    ],
    // 🏍️ 7. BIKES
    "Bikes": [
        { name: "make", placeholder: "Make (e.g., Honda, Yamaha)", type: "text", required: true },
        { name: "model", placeholder: "Model Name", type: "text", required: true },
        { name: "year", placeholder: "Manufacturing Year", type: "number", required: true },
        { name: "engineCC", placeholder: "Engine CC (e.g., 125, 70)", type: "number", required: true },
        { name: "mileage", placeholder: "Mileage (in KM)", type: "number" },
    ],
    // 🏭 8. BUSINESS, INDUSTRIAL & AGRICULTURE
    "Business": [
        { name: "businessType", placeholder: "Type (Franchise, Machinery)", type: "text", required: true },
        { name: "investmentRequired", placeholder: "Investment Required (PKR)", type: "number" },
        { name: "establishedYear", placeholder: "Year Established", type: "number" },
    ],
    // 🤝 9. SERVICES
    "Services": [
        { name: "serviceType", placeholder: "Service Type (e.g., Plumbing, Web Design)", type: "text", required: true },
        { name: "serviceArea", placeholder: "Service Area (City/Locality)", type: "text" },
        { name: "pricing", placeholder: "Pricing Structure", type: "text" },
    ],
    // 💼 10. JOBS
    "Jobs": [
        { name: "jobTitle", placeholder: "Job Title (e.g., Driver, Developer)", type: "text", required: true },
        { name: "salaryRange", placeholder: "Salary Range (PKR/Month)", type: "text" },
        { name: "jobType", placeholder: "Employment Type (Full-time, Part-time)", type: "select", options: ["Full-time", "Part-time", "Contract"], required: true },
        { name: "companyName", placeholder: "Company Name", type: "text" },
    ],
    // 🐾 11. ANIMALS
    "Animals": [
        { name: "animalType", placeholder: "Type (Dog, Cat, Bird)", type: "text", required: true },
        { name: "breed", placeholder: "Breed", type: "text" },
        { name: "age", placeholder: "Age (in months/years)", type: "text" },
        { name: "vaccination", placeholder: "Vaccination Status", type: "select", options: ["Vaccinated", "Not Vaccinated"], required: true },
    ],
    // 👗 12. FASHION & BEAUTY
    "Fashion": [
        { name: "itemType", placeholder: "Item Type (Shirt, Shoes, Makeup)", type: "text", required: true },
        { name: "size", placeholder: "Size (S, M, L, 40, etc.)", type: "text" },
        { name: "material", placeholder: "Material (Cotton, Leather)", type: "text" },
        { name: "gender", placeholder: "Gender", type: "select", options: ["Men", "Women", "Unisex"], required: true },
    ],
    // 📚 13. BOOKS, SPORTS & HOBBIES
    "Books": [
        { name: "productType", placeholder: "Type (Book, Sports Gear, Instrument)", type: "text", required: true },
        { name: "title", placeholder: "Book/Product Title", type: "text", required: true },
        { name: "author", placeholder: "Author/Brand", type: "text" },
        { name: "genre", placeholder: "Genre/Sport", type: "text" },
        { name: "conditionRating", placeholder: "Condition (1-10)", type: "number" },
    ],
    // 🧸 14. KIDS
    "Kids": [
        { name: "itemType", placeholder: "Item Type (Toy, Clothing, Stroller)", type: "text", required: true },
        { name: "ageGroup", placeholder: "Age Group (e.g., 2-5 years)", type: "text" },
        { name: "brand", placeholder: "Brand", type: "text" },
    ],
};

const getInitialState = () => ({
    images: [],
    imagePreviews: [],
    title: "",
    condition: "New", 
    description: "",
    price: "",
    location: "",
});

// User prop wahi rakha
const PostAd = ({ onClose, onAdAdded, category, user }) => {
    const [formData, setFormData] = useState(getInitialState()); 
    const [currentCategoryFields, setCurrentCategoryFields] = useState([]);

    useEffect(() => {
        const fields = CATEGORY_FIELDS[category] || [];
        setCurrentCategoryFields(fields);

        const dynamicFields = fields.reduce((acc, field) => {
            acc[field.name] = field.type === 'select' ? field.options[0] : "";
            return acc;
        }, {});

        setFormData(prev => ({ 
            ...getInitialState(), 
            ...prev,          
            ...dynamicFields      
        }));
    }, [category]);

    const inputHandler = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const imageHandler = (e) => {
        const files = Array.from(e.target.files);
        const previews = files.map((file) => URL.createObjectURL(file));
        setFormData({
            ...formData,
            images: [...formData.images, ...files],
            imagePreviews: [...formData.imagePreviews, ...previews],
        });
    };

    const submitForm = async (e) => {
        e.preventDefault();
        
        // 🔑 1. Local Storage se Firebase ID Token nikalen
        const firebaseIdToken = localStorage.getItem('firebaseIdToken'); 
        
        // Validation: Token zaroori hai
        if (!firebaseIdToken) {
            toast.error("Ad post karne ke liye pehle login zaroori hai.");
            return;
        }

        try {
            const finalFormData = new FormData();

            // 1. Append common fields
            Object.keys(formData).forEach((key) => {
                if (key !== "images" && key !== "imagePreviews") {
                    const value = ['price', 'mileage', 'year', 'batteryHealth', 'investmentRequired', 'bedrooms', 'bathrooms', 'age', 'conditionRating'].includes(key) 
                                        ? (Number(formData[key]) || 0) 
                                        : formData[key];
                    // 'userId' field ko ab hum FormData mein nahi bhejenge
                    if (key !== 'userId' && !currentCategoryFields.some(f => f.name === key)) {
                        finalFormData.append(key, value);
                    }
                }
            });

            // 2. Category
            finalFormData.append('category', category);
            
            // 3. Category-specific fields
            currentCategoryFields.forEach(field => {
                const value = ['price', 'mileage', 'year', 'batteryHealth', 'investmentRequired', 'bedrooms', 'bathrooms', 'age', 'conditionRating'].includes(field.name) 
                                        ? (Number(formData[field.name]) || 0)
                                        : formData[field.name];
                finalFormData.append(field.name, value);
            });

            // 4. Images
            formData.images.forEach((file) => finalFormData.append("images", file));

            // 🔑 2. AXIOS POST REQUEST WITH AUTHORIZATION HEADER
            const res = await axios.post("http://localhost:8000/api/ad", finalFormData, {
                headers: { 
                    "Content-Type": "multipart/form-data",
                    // 🔥 ZAROORI: Authorization Header add karen!
                    "Authorization": `Bearer ${firebaseIdToken}` 
                },
            });

            toast.success("Ad submitted successfully!");
            onClose();
            if (onAdAdded) onAdAdded(res.data.data);
        } catch (error) {
            console.error(error.response?.data || error.message);
            
            if (error.response?.status === 401 || error.response?.status === 403) {
                toast.error("Session expired or Unauthorized. Please re-login.");
            } else {
                toast.error("Something went wrong with the server or form data!");
            }
        }
    };

    return (
        <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-60 backdrop-blur-sm p-4 z-[999]">
            <button
                onClick={onClose}
                className="absolute top-6 right-6 w-10 h-10 flex items-center justify-center bg-white/80 backdrop-blur-md shadow-lg rounded-full text-gray-700 hover:bg-white transition"
            >
                ✕
            </button>

            <div className="bg-white/80 backdrop-blur-xl w-full max-w-xl p-6 rounded-3xl shadow-2xl border overflow-y-auto max-h-[90vh]">
                <h2 className="text-3xl font-extrabold text-center text-pink-600 mb-6">
                    Post Ad in: {category}
                </h2>

                <form onSubmit={submitForm} className="space-y-4">
                    <label className="block w-full p-4 border-2 border-dashed border-pink-400 rounded-xl text-center bg-white/60 cursor-pointer hover:bg-pink-50 transition">
                        <span className="text-gray-600">Upload Images (Multiple)</span>
                        <input type="file" name="images" multiple onChange={imageHandler} className="hidden" />
                    </label>

                    {formData.imagePreviews.length > 0 && (
                        <div className="w-full overflow-x-auto mt-2">
                            <div className="flex space-x-3 pb-2">
                                {formData.imagePreviews.map((img, index) => (
                                    <div key={index} className="min-w-[120px] h-[100px] rounded-xl overflow-hidden shadow-md border flex-shrink-0">
                                        <img src={img} alt={`preview-${index}`} className="w-full h-full object-cover" />
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    <Input name="title" value={formData.title} onChange={inputHandler} placeholder="Ad Title" />
                    <Select name="condition" value={formData.condition} onChange={inputHandler} options={["New", "Used"]} />

                    {currentCategoryFields.map((field) => {
                        if (field.dependsOn && formData[field.dependsOn.field] !== field.dependsOn.value) return null;
                        if (field.type === "select") {
                            return <Select key={field.name} name={field.name} value={formData[field.name] || field.options[0]} onChange={inputHandler} options={field.options} />;
                        }
                        return <Input key={field.name} name={field.name} value={formData[field.name] || ''} onChange={inputHandler} placeholder={field.placeholder} type={field.type || "text"} />;
                    })}

                    <textarea 
                        name="description" 
                        value={formData.description} 
                        onChange={inputHandler} 
                        rows="3" 
                        className="w-full border border-gray-300 rounded-xl p-3 text-sm bg-white/60 focus:ring-2 focus:ring-pink-400 outline-none" 
                        placeholder="Full Description..." 
                    />

                    <LocationDropdown
                        selected={formData.location}
                        onChange={(value) => setFormData({ ...formData, location: value })}
                        variant="form"
                    />

                    <Input name="price" value={formData.price} onChange={inputHandler} placeholder="Price" type="number" />

                    <button type="submit" className="w-full py-3 bg-gradient-to-r from-pink-600 to-purple-600 text-white rounded-xl font-bold text-lg shadow-lg hover:opacity-90 transition">
                        Submit Ad for {category}
                    </button>
                </form>
            </div>
        </div>
    );
};

const Input = ({ name, value, onChange, placeholder, type = "text" }) => (
    <input 
        type={type} 
        name={name} 
        value={value} 
        onChange={onChange} 
        placeholder={placeholder} 
        className="w-full border border-gray-300 rounded-xl p-3 text-sm bg-white/60 focus:ring-2 focus:ring-pink-400 outline-none" 
    />
);

const Select = ({ name, value, onChange, options }) => (
    <select name={name} value={value} onChange={onChange} className="w-full border border-gray-300 rounded-xl p-3 text-sm bg-white/60 focus:ring-2 focus:ring-pink-400 outline-none">
        {options.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
    </select>
);

export default PostAd;