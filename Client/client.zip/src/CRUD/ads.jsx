import React, { useEffect, useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";
import PostAd from "./postad"; 
import UpdateAd from "./updatead"; 
import CategorySelector from "../Components/CategorySelector"; 

// 🔑 Token fetch karne ka helper function
const getAuthHeaders = () => {
    const token = localStorage.getItem('firebaseIdToken');
    if (!token) {
        toast.error("Aapka session khatam ho chuka hai. Dobara login karein.");
        return {}; 
    }
    return {
        headers: {
            // 🔥 Token Authorization header mein bheja ja raha hai
            'Authorization': `Bearer ${token}` 
        }
    };
};

const Ads = ({ onClose, user }) => { // 🔑 User prop recieve kiya
    const [ads, setAds] = useState([]);
    const [showCategorySelector, setShowCategorySelector] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState(null);
    const [showPostModal, setShowPostModal] = useState(false);
    const [showUpdateModal, setShowUpdateModal] = useState(false);
    const [selectedAd, setSelectedAd] = useState(null);

    // === HANDLERS ===
    
    const handleCategorySelect = (categoryCode) => {
        setSelectedCategory(categoryCode);
        setShowCategorySelector(false);
        setShowPostModal(true); 
    };

    const handlePostAdClose = () => {
        setShowPostModal(false);
        setSelectedCategory(null);
    };
    
    // 🔑 Data Fetching: Sirf Login User ke Ads Fetch karna
    useEffect(() => {
        const fetchMyAds = async () => {
            const authHeaders = getAuthHeaders();
            // Agar token nahi mila, toh aage nahi badhna
            if (!authHeaders.headers) return; 

            try {
                // 🔥 API Path change kiya: /api/ads se /api/myads
                const res = await axios.get("http://localhost:8000/api/myads", authHeaders); 
                setAds(res.data);
            } catch (err) {
                // 404 (No Ads Found) aur 401 (Unauthorized) ko handle karna
                if (err.response?.status === 404) {
                    setAds([]); // Agar koi ad nahi mila toh khali list dikhao
                    // toast.info("Aapne abhi tak koi Ad post nahi kiya.");
                } else if (err.response?.status === 401 || err.response?.status === 403) {
                    toast.error("Session expired. Please sign in again.");
                    setAds([]);
                } else {
                    console.error("Error fetching my ads:", err);
                }
            }
        };

        fetchMyAds();
    }, []); // Hook sirf ek baar chalta hai, login ke baad

    // 🔑 Delete Ad: Token aur Ownership Check Zaroori
    const handleDelete = async (id) => {
        const authHeaders = getAuthHeaders();
        if (!authHeaders.headers) return; 
        
        try {
            // 🔥 API Path aur Token Header use kiya
            await axios.delete(`http://localhost:8000/api/ads/${id}`, authHeaders); 
            setAds(ads.filter((u) => u._id !== id));
            toast.success("Ad Deleted Successfully!");
        } catch (error) {
            console.error("Delete Error:", error.response?.data || error.message);
            if (error.response?.status === 403) {
                toast.error("Aap yeh ad delete nahi kar sakte (Ownership Error).");
            } else if (error.response?.status === 401) {
                 toast.error("Session error. Please login again.");
            } else {
                toast.error("Ad delete karne mein masla hua.");
            }
        }
    };

    const handleEdit = (ad) => {
        setSelectedAd(ad);
        setShowUpdateModal(true);
    };
    
    // Ad successfully add hone par list update karna
    const handleAdAdded = (newAd) => {
        // Naya ad list ke shuru mein add kiya, taaki turant dikhe
        setAds([newAd, ...ads]); 
    }

    // handleUpdate (UpdateAd component se call hoga)
    const handleAdUpdated = (updatedAd) => {
        setAds(ads.map((item) => (item._id === updatedAd._id ? updatedAd : item)));
    };


    return (
        <div className="fixed inset-0 bg-black/50 flex justify-center items-center z-50 p-4">
            {/* Modal Container */}
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 relative">
                <button
                    onClick={onClose}
                    className="absolute top-4 right-4 text-gray-600 hover:text-red-500 text-2xl font-bold"
                >
                    ✕
                </button>

                {/* Header */}
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-extrabold text-pink-600">My Ads (Private Listings)</h2>
                    <button
                        onClick={() => setShowCategorySelector(true)} 
                        className="bg-pink-600 text-white px-4 py-2 rounded-xl hover:bg-pink-500 shadow-md transition"
                    >
                        + New Ad
                    </button>
                </div>

                {/* Ads List */}
                <div className="space-y-6">
                    {ads.length === 0 && <p className="text-center text-gray-500 text-lg">Aapne abhi tak koi Ad post nahi kiya hai.</p>}
                    
                    {ads.map((ad) => ( 
                        <div
                            key={ad._id}
                            className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all border border-gray-200"
                        >
                            {/* Image Carousel (Wahi Rahega) */}
                            {ad.images && ad.images.length > 0 && (
                                <div className="flex overflow-x-auto gap-3 p-4 scrollbar-thin scrollbar-thumb-pink-300 scrollbar-track-gray-100">
                                    {ad.images.map((img, index) => (
                                        <div
                                            key={index}
                                            className="min-w-[140px] h-[100px] rounded-xl overflow-hidden flex-shrink-0 border border-gray-200 shadow-sm"
                                        >
                                            <img
                                                src={img}
                                                alt={`ad-img-${index}`}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>
                                    ))}
                                </div>
                            )}

                            {/* Ad Details Grid (Yahan Badlaav Hua) */}
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 p-4 border-t border-gray-100">
                                {/* Common Fields */}
                                <p><b>Category:</b> {ad.category}</p>
                                <p><b>Title:</b> {ad.title}</p>
                                <p><b>Condition:</b> {ad.condition}</p>

                                {/* DYNAMIC DETAILS (Wahi Rahega) */}
                                {ad.category === 'Mobile' && ad.details && (
                                    <>
                                        <p><b>Brand:</b> {ad.details.brand}</p>
                                        <p><b>Model:</b> {ad.details.model}</p>
                                        <p><b>Storage:</b> {ad.details.storage}</p>
                                        <p><b>RAM:</b> {ad.details.ram}</p>
                                        <p><b>PTA:</b> {ad.details.ptaStatus}</p>
                                    </>
                                )}
                                {ad.category === 'Car' && ad.details && (
                                    <>
                                        <p><b>Make:</b> {ad.details.make}</p>
                                        <p><b>Model:</b> {ad.details.carModel}</p>
                                        <p><b>Year:</b> {ad.details.year}</p>
                                        <p><b>Mileage:</b> {ad.details.mileage} KM</p>
                                    </>
                                )}
                                
                                {/* Final Common Fields */}
                                <p className="col-span-full"><b>Description:</b> {ad.description}</p>
                                <p><b>Price:</b> ${ad.price}</p>
                                <p><b>Location:</b> {ad.location}</p>
                                {/* 🔥 BADLAAV: User object se email ya display name dikhana */}
                                <p>
                                    <b>Posted By:</b> {user ? user.email || user.displayName || 'Self' : 'Loading...'}
                                </p>
                            </div>

                            {/* Action Buttons */}
                            <div className="flex justify-end gap-3 p-4 border-t border-gray-100">
                                <button
                                    onClick={() => handleEdit(ad)}
                                    className="bg-blue-500 text-white px-4 py-2 rounded-xl hover:bg-blue-600 transition shadow-md"
                                >
                                    Edit
                                </button>
                                <button
                                    onClick={() => handleDelete(ad._id)}
                                    className="bg-red-500 text-white px-4 py-2 rounded-xl hover:bg-red-600 transition shadow-md"
                                >
                                    Delete
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* 🔥 1. Category Selector Modal */}
            {showCategorySelector && (
                <CategorySelector
                    onClose={() => setShowCategorySelector(false)}
                    onCategorySelect={handleCategorySelect}
                />
            )}

            {/* 2. Post & Update Modals */}
            {showPostModal && selectedCategory && (
                <PostAd
                    onClose={handlePostAdClose} 
                    onAdAdded={handleAdAdded} 
                    category={selectedCategory} 
                    // user={user} // Agar aap user object prop mein bhej rahe hain
                />
            )}
            {showUpdateModal && (
                <UpdateAd
                    adData={selectedAd}
                    onClose={() => setShowUpdateModal(false)}
                    onUpdate={handleAdUpdated}
                    category={selectedAd.category} // 🔥 Category prop pass kiya
                />
            )}
        </div>
    );
};

export default Ads;