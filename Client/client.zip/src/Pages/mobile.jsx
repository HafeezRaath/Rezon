import React from 'react'
import Navbar from '../Components/Navbar'
import CategoryAds from '../Components/Categoryads' // CategoryAds import kiya

const Mobile = () => { 
  return (
    <div>
      <Navbar/>
      
      {/* 🔥 CategoryAds component ko seedha code pass kiya */}
      <CategoryAds defaultCategoryCode="Mobile" /> 
      
    </div>
  )
}

export default Mobile;