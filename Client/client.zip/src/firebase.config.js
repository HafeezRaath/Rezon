// Import Firebase
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBQvJ8cJ_c8q7lJrWHtHRDD9vdfgd4WSaw",
  authDomain: "otp-project-ef670.firebaseapp.com",
  projectId: "otp-project-ef670",
  storageBucket: "otp-project-ef670.appspot.com",
  messagingSenderId: "854222680516",
  appId: "1:854222680516:web:d3a506aa2b3aefabcdf491",
  measurementId: "G-FQC1ZES5PR"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Google provider (force account chooser)
const google = new GoogleAuthProvider();
google.setCustomParameters({ prompt: "select_account" });

export { auth, google };
