import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FaPaperPlane, FaArrowLeft, FaTag } from 'react-icons/fa';
import io from 'socket.io-client';
import axios from 'axios';

// Backend URL ke mutabiq socket connect karein
const socket = io.connect("http://localhost:8000");

const ChatRoom = ({ user }) => {
    const { conversationId } = useParams();
    const navigate = useNavigate();
    const [message, setMessage] = useState("");
    const [allMessages, setAllMessages] = useState([]);
    const [chatData, setChatData] = useState(null);
    const [isOnline, setIsOnline] = useState(false);
    const [lastSeen, setLastSeen] = useState(null);
    const scrollRef = useRef();

    // 🕒 Last Seen Format Helper
    const formatLastSeen = (date) => {
        if (!date || isNaN(new Date(date).getTime())) return "Offline";
        const now = new Date();
        const seenDate = new Date(date);
        
        if (now.toDateString() === seenDate.toDateString()) {
            return `Last seen at ${seenDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
        }
        return `Last seen on ${seenDate.toLocaleDateString()}`;
    };

    // 1. Fetch Chat History and Ad Info
    useEffect(() => {
        const fetchHistory = async () => {
            try {
                const res = await axios.get(`http://localhost:8000/api/chat/history/${conversationId}`, {
                    headers: { Authorization: `Bearer ${user?.accessToken}` }
                });
                setChatData(res.data);
                setAllMessages(res.data.chat.messages);
                
                // 🔑 Socket Signals
                socket.emit("join_chat", conversationId);
                socket.emit("user_online", user.uid);
                socket.emit("message_seen", { chatId: conversationId, userId: user.uid });
                
                // Set initial status of other user
                const other = res.data.users?.find(u => u.uid !== user?.uid);
                if (other) {
                    setIsOnline(other.isOnline);
                    setLastSeen(other.lastSeen);
                }
            } catch (err) {
                console.error("History fetch error:", err);
            }
        };
        if (user) fetchHistory();
    }, [conversationId, user]);

    // 2. Scroll to bottom
    useEffect(() => {
        scrollRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [allMessages]);

    // 3. Real-time Listeners
    useEffect(() => {
        socket.on("receive_message", (data) => {
            if (data.chatId === conversationId) {
                setAllMessages((prev) => [...prev, data]);
                // Screen par hotay hue foran seen mark karein
                socket.emit("message_seen", { chatId: conversationId, userId: user.uid });
            }
        });

        socket.on("status_change", (data) => {
            const otherUser = chatData?.users?.find(u => u.uid !== user?.uid);
            if (otherUser && data.userId === otherUser.uid) {
                setIsOnline(data.isOnline);
                setLastSeen(data.lastSeen);
            }
        });

        socket.on("messages_marked_read", (data) => {
            if (data.chatId === conversationId) {
                setAllMessages((prev) => prev.map(m => ({ ...m, isRead: true })));
            }
        });

        return () => {
            socket.off("receive_message");
            socket.off("status_change");
            socket.off("messages_marked_read");
        };
    }, [conversationId, chatData, user]);

    const handleSend = () => {
        if (!message.trim()) return;
        const msg = { 
            chatId: conversationId, 
            senderId: user.uid, 
            message, 
            timestamp: new Date(),
            isRead: false 
        };
        socket.emit("send_message", msg);
        setMessage("");
    };

    if (!chatData) return <div className="text-center p-10 font-bold text-pink-600">Loading Chat...</div>;

    const otherUser = chatData.users?.find(u => u.uid !== user?.uid);
    const ad = chatData.chat?.adId;

    return (
        <div className="min-h-screen bg-white flex justify-center p-0 md:p-4">
            <div className="w-full max-w-4xl bg-white flex flex-col h-[95vh] border shadow-lg relative overflow-hidden rounded-xl">
                
                {/* 👤 TOP HEADER */}
                <div className="p-3 border-b flex items-center bg-white sticky top-0 z-10">
                    <FaArrowLeft className="mr-3 cursor-pointer text-gray-600 hover:text-pink-600" onClick={() => navigate(-1)}/>
                    <div className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center text-white font-bold text-xl uppercase shadow-sm">
                        {otherUser?.name?.charAt(0)}
                    </div>
                    <div className="ml-3">
                        <h3 className="font-bold text-gray-800 text-sm leading-tight">{otherUser?.name}</h3>
                        <p className="text-[10px] font-medium leading-tight">
                            {isOnline ? <span className="text-green-500 font-bold">Online</span> : <span className="text-gray-500">{formatLastSeen(lastSeen)}</span>}
                        </p>
                    </div>
                </div>

                {/* 📦 AD STRIP */}
                {ad && (
                    <div className="p-2 border-b bg-gray-50 flex items-center justify-between px-4">
                        <div className="flex items-center min-w-0">
                            <img src={ad.images?.[0]} className="w-12 h-12 rounded object-cover border border-gray-200" alt="ad" />
                            <div className="ml-3 overflow-hidden">
                                <h4 className="font-bold text-[11px] uppercase text-gray-700 truncate">{ad.title}</h4>
                                <p className="text-pink-600 font-bold text-xs leading-none mt-1">Rs {ad.price?.toLocaleString()}</p>
                            </div>
                        </div>
                        <button 
                            onClick={() => navigate(`/`, { state: { openAdId: ad._id } })} 
                            className="bg-blue-600 text-white px-4 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-700 transition shadow-sm whitespace-nowrap ml-4"
                        >
                            View Ad
                        </button>
                    </div>
                )}

                {/* 💬 MESSAGES AREA */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 custom-scrollbar">
                    {allMessages.map((m, i) => (
                        <div key={i} className="flex flex-col">
                            <div className={`flex ${m.senderId === user?.uid ? 'justify-end' : 'justify-start'}`}>
                                <div className={`p-3 rounded-2xl max-w-[75%] text-sm shadow-sm ${
                                    m.senderId === user?.uid ? 'bg-pink-600 text-white rounded-tr-none' : 'bg-white text-gray-800 border rounded-tl-none'
                                }`}>
                                    <p className="leading-relaxed">{m.message}</p>
                                    <p className={`text-[8px] mt-1 text-right font-medium ${m.senderId === user?.uid ? 'text-pink-100' : 'text-gray-400'}`}>
                                        {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </p>
                                </div>
                            </div>
                            
                            {/* 🚀 INSTAGRAM STYLE SEEN TEXT */}
                            {m.senderId === user?.uid && m.isRead && i === allMessages.length - 1 && (
                                <p className="text-[10px] text-gray-400 text-right mr-1 mt-1 font-bold italic animate-pulse">Seen</p>
                            )}
                        </div>
                    ))}
                    <div ref={scrollRef} />
                </div>
                
                {/* ⌨️ INPUT AREA */}
                <div className="p-4 bg-white border-t flex items-center space-x-3">
                    <input 
                        className="flex-1 border border-gray-200 rounded-full px-5 py-2.5 text-sm outline-none bg-gray-50 focus:border-pink-500 transition-all" 
                        placeholder="Type a message..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    />
                    <button onClick={handleSend} className="bg-pink-600 text-white p-3.5 rounded-full hover:bg-pink-700 transition shadow-md active:scale-90">
                        <FaPaperPlane className="text-xs" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ChatRoom;