import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
    FaComments,
    FaRegBell,
    FaUserCircle,
} from "react-icons/fa";
import LocationDropdown from "./LocationDropdown";
import LoginPopup from "./LoginPopup";
import Ads from "../CRUD/ads";
import { auth } from "../firebase.config";
import { signOut, onAuthStateChanged } from "firebase/auth";

const Navbar = () => {
    const navigate = useNavigate();
    const [selectedLocation, setSelectedLocation] = useState("Pakistan");
    const [showLogin, setShowLogin] = useState(false);
    const [user, setUser] = useState(null);
    const [showDropdown, setShowDropdown] = useState(false);
    const [showAds, setShowAds] = useState(false);

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
            if (currentUser) {
                const photo = currentUser.photoURL || currentUser.providerData[0]?.photoURL || "/default-avatar.png";
                setUser({
                    ...currentUser,
                    photoURL: photo,
                    displayName: currentUser.displayName,
                    email: currentUser.email
                });
            } else {
                setUser(null);
            }
        });
        return () => unsubscribe();
    }, []);

    const handleLogout = async () => {
        try {
            await signOut(auth);
            setUser(null);
            setShowDropdown(false);
        } catch (error) {
            console.error("Logout error:", error);
        }
    };

    return (
        <nav className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 shadow-md py-3 px-4 md:px-12 flex items-center justify-between sticky top-0 z-50">
            
            {/* 1. Left Section: Logo & Location */}
            <div className="flex items-center gap-6">
                <Link to="/" className="text-2xl font-extrabold text-white tracking-tighter drop-shadow-md">
                    REZON
                </Link>

                {/* Navbar Location - Ab ye zyada prominent lagegi */}
                <div className="hidden sm:block">
                    <LocationDropdown
                        selected={selectedLocation}
                        onChange={(location) => {
                            setSelectedLocation(location);
                            navigate(`/?location=${location}`);
                        }}
                        variant="navbar"
                    />
                </div>
            </div>

            {/* 2. Right Section: Icons & Buttons */}
            <div className="flex items-center gap-5 text-white">
                
                {/* Chat Icon */}
                {user && (
                    <Link to="/conversations" className="relative hover:text-yellow-200 transition-colors">
                        <FaComments className="text-2xl" />
                        <span className="absolute -top-2 -right-2 bg-yellow-400 text-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold border border-red-500">
                            2
                        </span>
                    </Link>
                )}
                
                {/* Notifications */}
                <div className="relative cursor-pointer hover:text-yellow-200 transition-colors">
                    <FaRegBell className="text-2xl" />
                    <span className="absolute -top-2 -right-2 bg-yellow-400 text-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold border border-red-500">
                        4
                    </span>
                </div>

                {/* User Profile / Login */}
                <div className="relative">
                    {user ? (
                        <div className="flex items-center gap-2">
                             <img
                                src={user.photoURL}
                                alt="profile"
                                onClick={() => setShowDropdown(!showDropdown)}
                                className={`w-9 h-9 rounded-full border-2 cursor-pointer transition-all hover:scale-105 ${showDropdown ? "border-yellow-300" : "border-white"}`}
                            />
                        </div>
                    ) : (
                        <FaUserCircle
                            onClick={() => setShowLogin(true)}
                            className="text-3xl cursor-pointer hover:text-yellow-200"
                        />
                    )}

                    {/* Dropdown Menu */}
                    {showDropdown && user && (
                        <div className="absolute right-0 mt-3 w-56 bg-white text-black rounded-xl shadow-2xl py-2 z-50 border border-gray-100 animate-fadeIn">
                            <div className="px-4 py-3 border-b bg-gray-50 rounded-t-xl">
                                <p className="text-sm font-bold truncate">{user.displayName || "User"}</p>
                                <p className="text-[11px] text-gray-500 truncate">{user.email}</p>
                            </div>
                            <button className="w-full text-left px-4 py-2 text-sm hover:bg-orange-50 transition-colors">My Profile</button>
                            <button className="w-full text-left px-4 py-2 text-sm hover:bg-orange-50 transition-colors" onClick={() => { setShowAds(true); setShowDropdown(false); }}>My Ads</button>
                            <button className="w-full text-left px-4 py-2 text-sm hover:bg-orange-50 transition-colors">Settings</button>
                            <hr className="my-1" />
                            <button onClick={handleLogout} className="w-full text-left px-4 py-2 text-sm text-red-600 font-semibold hover:bg-red-50">Logout</button>
                        </div>
                    )}
                </div>

                {/* + Sell Button */}
                <button
                    onClick={() => user ? setShowAds(true) : setShowLogin(true)}
                    className="bg-white text-orange-600 font-bold text-sm px-6 py-2 rounded-full hover:bg-yellow-300 hover:text-orange-700 transition-all duration-300 shadow-md transform active:scale-95"
                >
                    + SELL
                </button>
            </div>

            {/* Modals */}
            {showAds && <Ads onClose={() => setShowAds(false)} user={user} />}
            {showLogin && <LoginPopup onClose={() => setShowLogin(false)} />}
        </nav>
    );
};

export default Navbar;