import React, { useState, useEffect } from 'react';
import { FaCommentDots, FaUserCircle, FaChevronRight } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ConversationList = ({ user }) => {
    const navigate = useNavigate();
    const [conversations, setConversations] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchInbox = async () => {
            if (!user) return;
            try {
                // Backend se populated list mangwana
                const res = await axios.get(`http://localhost:8000/api/chat/list/${user.uid}`, {
                    headers: { Authorization: `Bearer ${user.accessToken}` }
                });
                setConversations(res.data);
                setLoading(false);
            } catch (err) {
                console.error("Inbox load error:", err);
                setLoading(false);
            }
        };
        fetchInbox();
    }, [user]);

    if (loading) return (
        <div className="flex justify-center items-center min-h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-600"></div>
        </div>
    );

    return (
        <div className="min-h-screen bg-gray-50 p-2 md:p-6">
            <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
                {/* Header */}
                <div className="p-4 border-b bg-pink-600 text-white flex items-center shadow-sm">
                    <FaCommentDots className="mr-3 text-xl"/>
                    <h1 className="font-bold text-xl tracking-wide">INBOX</h1>
                </div>

                {/* Search Bar (Optional UI Touch) */}
                <div className="p-3 bg-gray-50 border-b">
                    <div className="relative">
                        <input 
                            type="text" 
                            placeholder="Search in chats..." 
                            className="w-full pl-4 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-pink-500 text-sm"
                        />
                    </div>
                </div>

                {/* Conversation List */}
                <div className="overflow-y-auto max-h-[75vh]">
                    {conversations.length > 0 ? conversations.map((conv) => (
                        <div 
                            key={conv._id}
                            onClick={() => navigate(`/chat/${conv._id}`)} 
                            className="flex items-center p-4 border-b cursor-pointer hover:bg-gray-50 transition-all duration-200 group"
                        >
                            {/* 1. Ad Thumbnail (Left Side) */}
                            <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 border border-gray-200 bg-gray-100 relative">
                                <img 
                                    src={conv.adDetails?.images?.[0] || "https://via.placeholder.com/150"} 
                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                                    alt="ad"
                                />
                            </div>

                            {/* 2. Chat Info (Middle) */}
                            <div className="flex-1 ml-4 min-w-0">
                                <div className="flex justify-between items-start">
                                    <p className="font-extrabold text-gray-900 truncate text-base">
                                        {conv.otherUserName || "User: " + conv.participants.find(p => p !== user?.uid).substring(0, 8) + "..."}
                                    </p>
                                    <span className="text-[10px] text-gray-400 font-medium uppercase ml-2">
                                        {new Date(conv.updatedAt).toLocaleDateString()}
                                    </span>
                                </div>
                                
                                {/* Ad Title in Pink (As per your demo) */}
                                <p className="text-xs font-bold text-pink-600 truncate mt-0.5">
                                    {conv.adDetails?.title || "Product Details"}
                                </p>
                                
                                {/* Last Message Snippet */}
                                <p className="text-sm text-gray-500 truncate mt-1 flex items-center">
                                    <span className="truncate">
                                        {conv.lastMessage || "Click to view messages..."}
                                    </span>
                                </p>
                            </div>

                            {/* 3. Arrow Icon (Right Side) */}
                            <div className="ml-2 text-gray-300 group-hover:text-pink-600 transition-colors">
                                <FaChevronRight size={14} />
                            </div>
                        </div>
                    )) : (
                        <div className="p-20 text-center">
                            <FaCommentDots className="mx-auto text-5xl text-gray-200 mb-4" />
                            <p className="text-gray-500 font-medium italic">Aapne abhi tak kisi se baat nahi ki.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ConversationList;