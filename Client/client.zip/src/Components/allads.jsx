import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import { FaTimes, FaArrowLeft, FaArrowRight, FaMapMarkerAlt, FaTag, FaPhoneAlt, FaSearch } from "react-icons/fa";
import toast from "react-hot-toast";

const MAIN_CATEGORIES = [
    { code: "All", name: "🏠 All Categories" },
    { code: "Mobile", name: "📱 Mobiles" },
    { code: "Car", name: "🚗 Vehicles" },
    { code: "PropertySale", name: "🏠 Property" },
    { code: "Electronics", name: "📺 Electronics" },
    { code: "Bikes", name: "🏍️ Bikes" },
    { code: "Furniture", name: "🛋️ Furniture" },
    { code: "Jobs", name: "💼 Jobs" },
];

const AllAds = ({ user }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const [ads, setAds] = useState([]);
    const [filteredAds, setFilteredAds] = useState([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [activeCategory, setActiveCategory] = useState("All");
    
    const [selectedAd, setSelectedAd] = useState(null);
    const [currentImageIndex, setCurrentImageIndex] = useState(0);

    useEffect(() => {
        axios.get("http://localhost:8000/api/ads")
            .then((res) => {
                setAds(res.data);
                setFilteredAds(res.data);
            })
            .catch((err) => console.log(err));
    }, []);

    useEffect(() => {
        let result = ads;
        if (activeCategory !== "All") {
            result = result.filter(ad => ad.category === activeCategory);
        }
        if (searchTerm) {
            result = result.filter(ad => 
                ad.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                ad.location.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        setFilteredAds(result);
    }, [searchTerm, activeCategory, ads]);

    useEffect(() => {
        if (location.state?.openAdId && ads.length > 0) {
            const adToOpen = ads.find(a => a._id === location.state.openAdId);
            if (adToOpen) {
                setSelectedAd(adToOpen);
                setCurrentImageIndex(0);
                window.history.replaceState({}, document.title);
            }
        }
    }, [location.state, ads]);

    const safeImage = (imgArray, index = 0) => {
        return imgArray && imgArray.length > 0 ? imgArray[index] : "https://via.placeholder.com/400x300?text=No+Image";
    };

    const handleInquiry = async () => {
        if (!user) return toast.error("Please login first!");
        if (user.uid === selectedAd.posted_by_uid) return toast.error("Own ad inquiry not allowed!");
        try {
            const res = await axios.post("http://localhost:8000/api/chat/start", {
                buyerId: user.uid,
                sellerId: selectedAd.posted_by_uid,
                adId: selectedAd._id
            });
            navigate(`/chat/${res.data.chatId}`);
        } catch (error) { toast.error("Server error!"); }
    };

    const renderDetails = (ad) => {
        if (!ad.details) return null;
        return Object.entries(ad.details).map(([key, value]) => (
            <p key={key} className="text-xs md:text-sm">
                <b>{key.replace(/([A-Z])/g, ' $1').replace(/^./, s => s.toUpperCase())}:</b> {value}
            </p>
        ));
    };

    const getRelatedAds = (currentAd) => {
        return ads.filter(ad => ad.category === currentAd.category && ad._id !== currentAd._id).slice(0, 6);
    };

    return (
        <div className="w-full min-h-screen bg-gray-50 pb-10">
            
            {/* 🔍 SEARCH & CATEGORIES */}
            <div className="p-4 md:p-8 bg-white border-b shadow-sm">
                <div className="relative max-w-4xl mx-auto mb-6">
                    <input 
                        type="text" placeholder="Search for anything..." 
                        className="w-full pl-12 pr-6 py-3 md:py-4 rounded-2xl border-2 border-gray-100 focus:border-pink-500 outline-none shadow-sm text-sm md:text-lg transition-all"
                        value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <FaSearch className="absolute left-4 md:left-5 top-3.5 md:top-5 text-gray-400 text-lg" />
                </div>
                
                {/* Responsive Category Chips */}
                <div className="flex space-x-2 overflow-x-auto pb-2 custom-scrollbar no-scrollbar">
                    {MAIN_CATEGORIES.map((cat) => (
                        <button 
                            key={cat.code} 
                            onClick={() => setActiveCategory(cat.code)}
                            className={`px-4 md:px-6 py-2 rounded-full font-bold text-xs md:text-sm border transition-all whitespace-nowrap ${
                                activeCategory === cat.code 
                                ? "bg-pink-600 text-white border-pink-600" 
                                : "bg-white text-gray-500 border-gray-200 hover:border-pink-200"
                            }`}
                        >
                            {cat.name}
                        </button>
                    ))}
                </div>
            </div>

            {/* 📢 ADS GRID - Mobile: 2 columns | Desktop: up to 6 columns */}
            <div className="p-2 md:p-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 md:gap-6">
                {filteredAds.map((ad) => (
                    <div key={ad._id} onClick={() => { setSelectedAd(ad); setCurrentImageIndex(0); }}
                        className="bg-white rounded-xl md:rounded-3xl shadow-sm border border-gray-100 p-2 md:p-4 cursor-pointer transition-all hover:shadow-md">
                        <div className="relative h-32 md:h-48 rounded-lg md:rounded-2xl overflow-hidden mb-2 md:mb-4">
                            <img src={safeImage(ad.images)} className="w-full h-full object-cover" alt={ad.title} />
                            <div className="absolute top-2 left-2 bg-white/90 px-2 py-0.5 rounded text-[8px] md:text-[10px] font-black text-pink-600 shadow-sm uppercase">
                                {ad.category}
                            </div>
                        </div>
                        <h2 className="font-bold text-gray-800 truncate text-xs md:text-base">{ad.title}</h2>
                        <span className="text-sm md:text-xl font-black text-pink-600 block mt-1">Rs {ad.price?.toLocaleString()}</span>
                        <p className="text-gray-400 text-[9px] md:text-[11px] mt-2 truncate flex items-center">
                            <FaMapMarkerAlt className="mr-1 text-pink-400" /> {ad.location}
                        </p>
                    </div>
                ))}
            </div>

            {/* 🔥 MODAL SECTION - Mobile Responsive Modal */}
            {selectedAd && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex justify-center items-center z-[100] md:p-10">
                    {/* Modal Box: Full screen on mobile, max-width on desktop */}
                    <div className="bg-white w-full h-full md:h-auto md:max-h-[90vh] md:max-w-6xl md:rounded-3xl shadow-2xl relative flex flex-col overflow-hidden">
                        
                        {/* Header for Mobile */}
                        <div className="flex items-center justify-between p-4 border-b md:hidden">
                            <button onClick={() => setSelectedAd(null)}><FaArrowLeft size={20}/></button>
                            <span className="font-bold text-sm">Ad Details</span>
                            <div className="w-5"></div>
                        </div>

                        {/* Desktop Close Button */}
                        <button onClick={() => setSelectedAd(null)} className="hidden md:block absolute top-5 right-5 text-3xl text-gray-400 hover:text-red-500 z-10">&times;</button>
                        
                        <div className="overflow-y-auto p-4 md:p-8 flex-1">
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-10">
                                {/* Image Section */}
                                <div className="relative h-64 md:h-[450px] rounded-xl md:rounded-3xl overflow-hidden border">
                                    <img src={safeImage(selectedAd.images, currentImageIndex)} className="w-full h-full object-cover" alt="" />
                                    {selectedAd.images?.length > 1 && (
                                        <div className="absolute inset-0 flex items-center justify-between px-2 md:px-4">
                                            <button onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(p => (p - 1 + selectedAd.images.length) % selectedAd.images.length); }} className="bg-white/80 p-2 md:p-3 rounded-full text-pink-600 shadow-md"><FaArrowLeft size={16}/></button>
                                            <button onClick={(e) => { e.stopPropagation(); setCurrentImageIndex(p => (p + 1) % selectedAd.images.length); }} className="bg-white/80 p-2 md:p-3 rounded-full text-pink-600 shadow-md"><FaArrowRight size={16}/></button>
                                        </div>
                                    )}
                                </div>

                                {/* Text Details */}
                                <div className="flex flex-col justify-between">
                                    <div>
                                        <h2 className="text-xl md:text-4xl font-black text-gray-900 mb-2 md:mb-4">{selectedAd.title}</h2>
                                        <span className="text-2xl md:text-5xl font-black text-pink-600 block mb-3 md:mb-6">Rs {selectedAd.price?.toLocaleString()}</span>
                                        <div className="flex items-center text-gray-600 text-xs md:text-lg mb-4 md:mb-8"><FaMapMarkerAlt className="mr-2 text-pink-500" /> {selectedAd.location}</div>
                                        
                                        <div className="mt-4 md:mt-6 border-t pt-4 md:pt-6">
                                            <h3 className="text-sm md:text-xl font-bold mb-3">Item Details</h3>
                                            <div className="grid grid-cols-2 gap-3 text-gray-700 italic">
                                                {renderDetails(selectedAd)}
                                                <p className="text-xs md:text-sm"><b>Condition:</b> {selectedAd.condition}</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mt-6 md:mt-10 space-y-3">
                                        <button onClick={handleInquiry} className="w-full bg-green-500 text-white py-3 md:py-4 rounded-xl md:rounded-2xl font-bold md:text-xl shadow-lg active:scale-95 transition">Inquire Now</button>
                                        <button className="w-full bg-blue-500 text-white py-3 md:py-4 rounded-xl md:rounded-2xl flex items-center justify-center font-bold md:text-xl shadow-lg"><FaPhoneAlt className="mr-3" /> Contact Seller</button>
                                    </div>
                                </div>
                            </div>

                            {/* Description Section */}
                            <div className="mt-8 md:mt-12 border-t pt-6 md:pt-8">
                                <h4 className="font-black text-lg md:text-2xl mb-3 md:mb-4">Description</h4>
                                <p className="text-gray-600 text-sm md:text-lg leading-relaxed whitespace-pre-wrap">{selectedAd.description}</p>
                            </div>

                            {/* Related Ads */}
                            {getRelatedAds(selectedAd).length > 0 && (
                                <div className="mt-10 md:mt-16">
                                    <h3 className="text-lg md:text-3xl font-black text-gray-800 mb-4 md:mb-6">Related Ads</h3>
                                    <div className="flex overflow-x-auto space-x-4 md:space-x-6 pb-6 no-scrollbar">
                                        {getRelatedAds(selectedAd).map((related) => (
                                            <div key={related._id} onClick={() => {setSelectedAd(related); setCurrentImageIndex(0);}} className="bg-gray-50 rounded-2xl shadow-sm p-3 w-40 md:w-64 flex-shrink-0 cursor-pointer">
                                                <img src={safeImage(related.images)} className="h-24 md:h-40 w-full object-cover rounded-xl" alt="" />
                                                <h4 className="font-bold text-gray-800 mt-2 truncate text-xs md:text-base">{related.title}</h4>
                                                <span className="text-xs md:text-lg font-black text-pink-600 block">Rs {related.price?.toLocaleString()}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AllAds;