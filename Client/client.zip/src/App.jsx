import React, { useState, useEffect } from "react";
import { Routes, Route, useLocation, useNavigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth"; // Firebase listener
import { auth } from "./firebase.config"; // Aapka firebase config file

import Home from "./Pages/Home";
import LoginPopup from "./Components/LoginPopup";
import SigninPopup from "./Components/Signinpopup";
import Ads from "./CRUD/ads";
import CategoryAds from "./Components/Categoryads"; 
import ConversationList from "./Components/ConservationList"; 
import ChatRoom from "./Components/ChatRoom";
import Navbar from "./Components/Navbar"; // Agar Navbar yahan use ho raha hai

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const background = location.state?.backgroundLocation;

  // 🔑 1. User State manage karein
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Firebase auth state check karein
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        setUser(null);
      }
    });
    return () => unsubscribe();
  }, []);

  return (
    <>
      {/* Agar Navbar use kar rahe hain to usey bhi user bhej dein */}
      <Navbar user={user} /> 

      {/* ✅ Main page routes */}
      <Routes location={background || location}>
        <Route path="/" element={<Home user={user} />} />
        
        {/* Category Routes */}
        <Route path="/mobiles" element={<CategoryAds user={user} />} /> 
        <Route path="/vehicles" element={<CategoryAds user={user} />} /> 
        <Route path="/property-for-sale" element={<CategoryAds user={user} />} />
        <Route path="/electronics" element={<CategoryAds user={user} />} />
        <Route path="/bikes" element={<CategoryAds user={user} />} />
        <Route path="/furniture" element={<CategoryAds user={user} />} />
        <Route path="/category/:slug" element={<CategoryAds user={user} />} /> 

        {/* ========================================================= */}
        {/* ✅ CHAT ROUTES (Updated with User Prop) */}
        {/* ========================================================= */}
        
        {/* 1. Inbox List */}
        <Route path="/conversations" element={<ConversationList user={user} />} />
        
        {/* 2. Chat Room */}
        <Route path="/chat/:conversationId" element={<ChatRoom user={user} />} />
        
      </Routes>

      {/* ✅ Popup / Modal routes */}
      {background && (
        <Routes>
          <Route
            path="/login"
            element={<LoginPopup onClose={() => navigate(-1)} />}
          />
          <Route
            path="/signin"
            element={<SigninPopup onClose={() => navigate(-1)} />}
          />
          <Route
            path="/ads"
            element={<Ads onClose={() => navigate(-1)} user={user} />}
          />
        </Routes>
      )}
    </>
  );
}

export default App;