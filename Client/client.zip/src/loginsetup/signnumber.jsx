import React, { useState } from 'react';
import { CgSpinner } from 'react-icons/cg';
import OTPInput from 'react-otp-input';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import { auth } from '../firebase.config';
import { RecaptchaVerifier, signInWithPhoneNumber } from 'firebase/auth';
import toast, { Toaster } from 'react-hot-toast';

export default function Signin({ onClose }) {
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [ph, setPh] = useState('');
  const [showOTP, setShowOTP] = useState(false);
  const [user, setUser] = useState(null);

  function onCaptchVerify() {
    if (!window.recaptchaVerifier) {
      window.recaptchaVerifier = new RecaptchaVerifier(
        'recaptcha-container',
        {
          size: 'invisible',
          callback: (response) => {
            onSignup();
          },
          'expired-callback': () => {}
        },
        auth
      );
    }
  }

  function onSignup() {
    setLoading(true);
    onCaptchVerify();

    const appVerifier = window.recaptchaVerifier;
    const formatPh = '+' + ph;

    signInWithPhoneNumber(auth, formatPh, appVerifier)
      .then((confirmationResult) => {
        window.confirmationResult = confirmationResult;
        setLoading(false);
        setShowOTP(true);
        toast.success('OTP sent successfully!');
      })
      .catch((error) => {
        console.log(error);
        toast.error('Failed to send OTP');
        setLoading(false);
      });
  }

  function onOTPVerify() {
    setLoading(true);
    window.confirmationResult
      .confirm(otp)
      .then((res) => {
        setUser(res.user); // ✅ fix
        toast.success('Login successful!');
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
        toast.error('Invalid OTP');
        setLoading(false);
      });
  }

  return (
    <div className="fixed inset-0 z-50 bg-white bg-opacity-40 backdrop-blur-sm flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-black rounded-xl p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-2 right-2 text-gray-600 hover:text-red-500 text-xl font-bold"
        >
          &times;
        </button>

        <Toaster toastOptions={{ duration: 4000 }} />
        <div id="recaptcha-container"></div>

        {!user ? (
          showOTP ? (
            <>
              <label className="block mb-2 text-lg font-semibold text-white">
                Enter Your OTP
              </label>

              <OTPInput
                value={otp}
                onChange={setOtp}
                numInputs={6}
                autoFocus
                renderInput={(props) => (
                  <input
                    {...props}
                    className="bg-black text-white border border-gray-400 rounded p-1 m-1 w-28 text-center text-xl focus:outline-none focus:ring-2 focus:ring-white"
                  />
                )}
              />

              <button
                onClick={onOTPVerify}
                className="mt-4 px-2 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md flex items-center justify-center hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-200"
              >
                {loading && (
                  <CgSpinner size={20} className="animate-spin mr-2" />
                )}
                <span>Verify OTP</span>
              </button>
            </>
          ) : (
            <>
              <label className="block mb-2 text-lg font-semibold text-white">
                Verify Your Phone Number
              </label>

              <PhoneInput
                country={'pk'}
                inputClass="!w-full !text-black"
                value={ph}
                onChange={setPh}
              />

              <button
                onClick={onSignup}
                className="mt-4 px-2 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md flex items-center justify-center hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-200"
              >
                {loading && (
                  <CgSpinner size={20} className="animate-spin mr-2" />
                )}
                <span>Send OTP via SMS</span>
              </button>
            </>
          )
        ) : (
          <h2 className="text-white text-center mt-4">✅ Login Successful</h2>
        )}
      </div>
    </div>
  );
}
